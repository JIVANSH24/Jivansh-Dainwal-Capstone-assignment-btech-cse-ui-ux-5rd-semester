class ValidationError(ValueError):
    """Raised when user or file input is invalid."""
