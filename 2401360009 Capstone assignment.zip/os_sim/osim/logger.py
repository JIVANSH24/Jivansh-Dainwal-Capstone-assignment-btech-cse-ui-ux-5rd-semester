"""Activity logging shared by every module."""
import logging, os

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")

def get_logger(name="osim"):
    log = logging.getLogger(name)
    if not log.handlers:
        os.makedirs(LOG_DIR, exist_ok=True)
        h = logging.FileHandler(os.path.join(LOG_DIR, "activity.log"))
        h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"))
        log.addHandler(h)
        log.setLevel(logging.INFO)
    return log
