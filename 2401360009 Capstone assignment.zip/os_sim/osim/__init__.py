"""OS Resource-Management Simulator (OSRMS)."""
