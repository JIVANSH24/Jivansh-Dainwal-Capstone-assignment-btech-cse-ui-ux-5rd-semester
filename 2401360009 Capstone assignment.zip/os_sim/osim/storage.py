"""Disk-scheduling simulation: FCFS, SSTF, SCAN, C-SCAN, LOOK."""
from .errors import ValidationError

def _check(reqs, head, disk):
    if not reqs: raise ValidationError("Request queue is empty")
    if not (0 <= head < disk): raise ValidationError(f"Head {head} outside disk 0..{disk-1}")
    bad = [r for r in reqs if not (0 <= r < disk)]
    if bad: raise ValidationError(f"Cylinders out of range 0..{disk-1}: {bad}")

def _res(name, order, head):
    pos, total = head, 0
    for c in order:
        total += abs(c - pos); pos = c
    return {"algorithm": name, "order": order, "total_movement": total}

def _split(reqs, head):
    return sorted(r for r in reqs if r < head), sorted(r for r in reqs if r >= head)

def fcfs(reqs, head, disk=200):
    _check(reqs, head, disk); return _res("FCFS", list(reqs), head)

def sstf(reqs, head, disk=200):
    _check(reqs, head, disk)
    left, pos, order = list(reqs), head, []
    while left:
        c = min(left, key=lambda x: abs(x - pos)); left.remove(c); order.append(c); pos = c
    return _res("SSTF", order, head)

def scan(reqs, head, disk=200):
    _check(reqs, head, disk)
    lo, hi = _split(reqs, head)
    return _res("SCAN", hi + ([disk - 1] if lo else []) + lo[::-1], head)

def cscan(reqs, head, disk=200):
    _check(reqs, head, disk)
    lo, hi = _split(reqs, head)
    return _res("C-SCAN", hi + ([disk - 1, 0] if lo else []) + lo, head)

def look(reqs, head, disk=200):
    _check(reqs, head, disk)
    lo, hi = _split(reqs, head)
    return _res("LOOK", hi + lo[::-1], head)

DISK_ALGOS = {"FCFS": fcfs, "SSTF": sstf, "SCAN": scan, "C-SCAN": cscan, "LOOK": look}

def compare_disk(reqs, head, disk=200):
    return {n: fn(reqs, head, disk) for n, fn in DISK_ALGOS.items()}
