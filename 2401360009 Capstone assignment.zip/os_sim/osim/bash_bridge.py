"""Python <-> Bash integration."""
import os, subprocess
from .errors import ValidationError
from .logger import get_logger

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
log = get_logger("bash")

def run_script(name, *args, timeout=15):
    path = os.path.join(ROOT, "bash", name)
    if not os.path.isfile(path):
        raise ValidationError(f"Missing script {name}")
    try:
        p = subprocess.run(["bash", path, *map(str, args)], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        log.error("script %s timed out", name); raise ValidationError(f"{name} timed out")
    log.info("bash %s %s -> rc=%s", name, args, p.returncode)
    if p.returncode != 0:
        raise ValidationError(f"{name} failed: {p.stderr.strip()}")
    return p.stdout

def sysinfo():
    return run_script("sysinfo.sh")

def collect_live_processes(count=8, out_path=None):
    out_path = out_path or os.path.join(ROOT, "data", "live_processes.csv")
    text = run_script("collect_procs.sh", count)
    with open(out_path, "w") as f:
        f.write(text)
    return out_path
