"""Memory management: page replacement + contiguous allocation."""
from .errors import ValidationError

def _check(refs, frames):
    if not refs:
        raise ValidationError("Reference string is empty")
    if not isinstance(frames, int) or frames < 1:
        raise ValidationError(f"Frames must be a positive integer, got {frames!r}")

def _result(name, refs, faults, trace):
    return {"algorithm": name, "faults": faults, "hits": len(refs) - faults,
            "fault_rate": faults / len(refs), "trace": trace}

def fifo(refs, frames):
    _check(refs, frames)
    mem, faults, trace = [], 0, []
    for r in refs:
        hit = r in mem
        if not hit:
            faults += 1
            if len(mem) == frames: mem.pop(0)
            mem.append(r)
        trace.append((r, list(mem), "HIT" if hit else "FAULT"))
    return _result("FIFO", refs, faults, trace)

def lru(refs, frames):
    _check(refs, frames)
    mem, faults, trace = [], 0, []
    for r in refs:
        hit = r in mem
        if hit:
            mem.remove(r)
        else:
            faults += 1
            if len(mem) == frames: mem.pop(0)
        mem.append(r)
        trace.append((r, list(mem), "HIT" if hit else "FAULT"))
    return _result("LRU", refs, faults, trace)

def optimal(refs, frames):
    _check(refs, frames)
    mem, faults, trace = [], 0, []
    for i, r in enumerate(refs):
        hit = r in mem
        if not hit:
            faults += 1
            if len(mem) == frames:
                def nxt(p):
                    try: return refs.index(p, i + 1)
                    except ValueError: return float("inf")
                mem.remove(max(mem, key=nxt))
            mem.append(r)
        trace.append((r, list(mem), "HIT" if hit else "FAULT"))
    return _result("Optimal", refs, faults, trace)

PAGE_ALGOS = {"FIFO": fifo, "LRU": lru, "Optimal": optimal}

def compare_paging(refs, frame_counts):
    return {f: {n: fn(refs, f) for n, fn in PAGE_ALGOS.items()} for f in frame_counts}

def allocate(blocks, requests, strategy="first"):
    """Contiguous allocation: first/best/worst fit."""
    if strategy not in ("first", "best", "worst"):
        raise ValidationError("strategy must be first/best/worst")
    if not blocks or not requests:
        raise ValidationError("blocks and requests must be non-empty")
    free, alloc = list(blocks), []
    for req in requests:
        cand = [(i, b) for i, b in enumerate(free) if b >= req]
        if not cand:
            alloc.append((req, None)); continue
        i, _ = {"first": cand[0], "best": min(cand, key=lambda c: c[1]),
                "worst": max(cand, key=lambda c: c[1])}[strategy]
        alloc.append((req, i)); free[i] -= req
    unplaced = [r for r, i in alloc if i is None]
    return {"strategy": strategy, "allocations": alloc, "free": free,
            "unplaced": unplaced,
            "external_fragmentation": sum(free) if unplaced else 0,
            "utilization": 100.0 * sum(r for r, i in alloc if i is not None) / sum(blocks)}
