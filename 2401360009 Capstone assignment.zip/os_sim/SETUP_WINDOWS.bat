@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m pip install --upgrade pip
  py -3 -m pip install -r requirements.txt
) else (
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
)
if errorlevel 1 (
  echo.
  echo Installation failed. Install Python 3 from https://www.python.org/downloads/windows/
  echo During installation, select "Add Python to PATH".
  pause
  exit /b 1
)
echo.
echo Setup complete. Run RUN_WINDOWS.bat to start the project.
pause
