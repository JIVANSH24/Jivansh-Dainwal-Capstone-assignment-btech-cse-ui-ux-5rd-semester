#!/usr/bin/env bash
# Builds a scheduler dataset (pid,arrival,burst,priority) from REAL processes.
# usage: collect_procs.sh [count=8] > data/live_processes.csv
set -u
N="${1:-8}"
case "$N" in ''|*[!0-9]*) echo "count must be a positive integer" >&2; exit 2;; esac
[ "$N" -ge 1 ] || { echo "count must be >= 1" >&2; exit 2; }
echo "pid,arrival,burst,priority"
ps -eo pid,cputimes,ni --no-headers --sort=-cputimes 2>/dev/null | head -n "$N" |
awk '{ i++; b=$2; if (b<1) b=(($1%9)+1); if (b>20) b=20;
       p=$3+21; if (p<1) p=1; if (p>40) p=40;
       printf "P%s,%d,%d,%d\n", $1, (i-1)*2, b, p }'
