#!/usr/bin/env python3
"""OS Resource-Management Simulator - menu-driven entry point.

  python3 main.py            interactive menu
  python3 main.py --demo     run every module on the sample data, write outputs/
"""
import argparse, json, os, sys, platform, shutil
from osim import scheduler, memory, deadlock, storage, report, bash_bridge
from osim.errors import ValidationError
from osim.validators import load_processes, int_list, positive_int
from osim.logger import get_logger

ROOT = os.path.dirname(os.path.abspath(__file__))
D = lambda f: os.path.join(ROOT, "data", f)
log = get_logger("main")

def read_text(path):
    try:
        with open(path) as f: return f.read()
    except OSError as e:
        raise ValidationError(f"Cannot open {path}: {e.strerror}")

# ---------------------------------------------------------------- modules
def run_scheduler(path=None, quantum=4):
    procs = load_processes(path or D("processes.csv"))
    res = scheduler.compare(procs)
    res["RR(q=4)"] = scheduler.round_robin(procs, quantum) if quantum != 4 else res["RR(q=4)"]
    print("\n== CPU SCHEDULING ==")
    for n, r in res.items():
        print(f"\n{n}\n  Gantt: {report.gantt_text(r['gantt'])}")
    print("\n" + report.sched_table(res))
    best = min(res, key=lambda n: res[n]["avg_waiting"])
    print(f"\nObservation: lowest average waiting time -> {best} ({res[best]['avg_waiting']:.2f}).")
    charts = [report.chart_gantt(res), report.chart_sched(res)]
    log.info("scheduler run: %d processes, best=%s", len(procs), best)
    return res, charts

def run_memory(refs=None, frames=(1, 2, 3, 4, 5, 6, 7)):
    refs = refs or int_list(read_text(D("pages.txt")), "page", 0, 10**4)
    cmp = memory.compare_paging(refs, list(frames))
    print("\n== MEMORY: PAGE REPLACEMENT ==\nReference string:", *refs)
    print("\nTrace (3 frames, LRU):")
    for page, mem, st in cmp[3]["LRU"]["trace"]:
        print(f"  page {page:>2} -> {str(mem):<12} {st}")
    print("\n" + report.paging_table(cmp))
    txt = read_text(D("memory_blocks.txt")).splitlines()
    blocks = int_list(txt[0].split(":")[1], "block", 1)
    reqs = int_list(txt[1].split(":")[1], "request", 1)
    print("\nContiguous allocation:")
    rows = []
    for s in ("first", "best", "worst"):
        a = memory.allocate(blocks, reqs, s)
        rows.append([s + "-fit", a["allocations"].__str__(), f"{a['utilization']:.1f}%", a["unplaced"] or "-"])
    print(report.table(["Strategy", "(request, block#)", "Utilisation", "Unplaced"], rows))
    chart = report.chart_paging(cmp)
    log.info("memory run: %d refs", len(refs))
    return cmp, [chart]

def load_banker(path=None):
    try:
        return json.loads(read_text(path or D("banker.json")))
    except json.JSONDecodeError as e:
        raise ValidationError(f"Invalid JSON: {e}")

def run_deadlock(path=None, req=(1, 1, 0, 2)):
    st = load_banker(path)
    A, M, V = st["allocation"], st["max"], st["available"]
    s = deadlock.safety(A, M, V)
    print("\n== DEADLOCK: BANKER'S ALGORITHM ==")
    print(report.table(["Process", "Need"], [[f"P{i}", n] for i, n in enumerate(s["need"])]))
    print("Safe state:", s["safe"], "| Safe sequence:", " -> ".join(s["sequence"]) or "none")
    pid, vec = req[0], list(req[1:])
    r = deadlock.request(A, M, V, pid, vec)
    print(f"Request P{pid}{vec}: {'GRANTED' if r['granted'] else 'DENIED'} ({r['reason']})")
    bad = deadlock.request(A, M, V, 0, [0, 4, 0])
    print(f"Request P0[0, 4, 0]: {'GRANTED' if bad['granted'] else 'DENIED'} ({bad['reason']})")
    cyc = deadlock.detect_cycle({"P1": ["P2"], "P2": ["P3"], "P3": ["P1"], "P4": ["P1"]})
    print("Wait-for graph cycle (deadlock detection):", " -> ".join(cyc) if cyc else "none")
    log.info("deadlock run: safe=%s", s["safe"])
    return s, []

def run_storage(reqs=None, head=53, disk=200):
    reqs = reqs or int_list(read_text(D("disk_requests.txt")), "cylinder", 0, disk - 1)
    res = storage.compare_disk(reqs, head, disk)
    print(f"\n== STORAGE: DISK SCHEDULING (head={head}, cylinders 0-{disk-1}) ==")
    print(report.disk_table(res))
    best = min(res, key=lambda n: res[n]["total_movement"])
    print(f"\nObservation: {best} minimises head movement ({res[best]['total_movement']}).")
    chart = report.chart_disk(res, head)
    log.info("storage run: best=%s", best)
    return res, [chart]

def run_report():
    if os.name == "nt":
        print("\\n== SYSTEM REPORT (Windows) ==")
        print(f"Operating system: {platform.system()} {platform.release()}")
        print(f"Machine: {platform.machine()}")
        print(f"Processor: {platform.processor() or 'Not reported'}")
        print(f"Logical CPU count: {os.cpu_count() or 'Not reported'}")
        total, used, free = shutil.disk_usage(ROOT)
        print(f"Project drive free space: {free // (1024**3)} GB")
        print("Bash-only live process collection is skipped on Windows.")
        print("The CPU, memory, deadlock and disk simulations work normally.")
    else:
        print("\\n== SYSTEM REPORT (Bash integration) ==")
        print(bash_bridge.sysinfo())
        path = bash_bridge.collect_live_processes(6)
        print(f"Live process dataset written to {os.path.relpath(path, ROOT)}; scheduling it with RR:")
        r = scheduler.round_robin(load_processes(path), 4)
        print(f"  avg waiting={r['avg_waiting']:.2f}  avg turnaround={r['avg_turnaround']:.2f}")
    log.info("report run")

# ------------------------------------------------------------------- menu
MENU = """
==== OS Resource-Management Simulator ====
 1) CPU scheduling         4) Disk/storage scheduling
 2) Memory management      5) Live system report (Bash)
 3) Deadlock (Banker's)    6) Run everything (demo)
 0) Exit
"""

def ask(prompt, default=""):
    v = input(f"{prompt} [{default}]: ").strip()
    return v or default

def interactive():
    while True:
        print(MENU)
        c = input("Choice: ").strip()
        try:
            if c == "0": print("Goodbye."); return
            elif c == "1":
                q = positive_int(ask("Time quantum", "4"), "quantum", 1, 1000)
                run_scheduler(ask("CSV path", D("processes.csv")), q)
            elif c == "2":
                refs = int_list(ask("Reference string", "7 0 1 2 0 3 0 4 2 3 0 3 2"), "page", 0, 10**4)
                f = positive_int(ask("Max frames", "5"), "frames", 1, 50)
                run_memory(refs, range(1, f + 1))
            elif c == "3": run_deadlock(ask("JSON path", D("banker.json")))
            elif c == "4":
                reqs = int_list(ask("Cylinder requests", "98 183 37 122 14 124 65 67"), "cylinder", 0, 199)
                run_storage(reqs, positive_int(ask("Head position", "53"), "head", 0, 199))
            elif c == "5": run_report()
            elif c == "6": demo()
            else: print("Invalid choice - enter 0-6.")
        except ValidationError as e:
            print(f"[input error] {e}"); log.warning("validation: %s", e)
        except Exception as e:  # last-resort guard so the menu never crashes
            print(f"[unexpected error] {e}"); log.exception("unexpected")

def demo():
    charts = []
    for fn in (run_scheduler, run_memory, run_deadlock, run_storage):
        charts += fn()[1]
    run_report()
    print("\nCharts saved:", *[os.path.relpath(c, ROOT) for c in charts], sep="\n  ")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("--demo", action="store_true", help="non-interactive full run")
    a = ap.parse_args()
    log.info("start demo=%s", a.demo)
    try:
        demo() if a.demo else interactive()
    except ValidationError as e:
        print(f"[input error] {e}", file=sys.stderr); sys.exit(2)
    except (EOFError, KeyboardInterrupt):
        print("\nInterrupted."); sys.exit(130)
